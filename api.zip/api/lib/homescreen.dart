import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Homescreen extends StatefulWidget {
  const Homescreen({super.key});

  @override
  State<Homescreen> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<Homescreen> {
  bool isApiResponseLoading=false;
  String RandomBucketList="RandumBucketList";

  //making an api call
  Future<void> fetchRandumBucketList()async {
    setState(() {
      isApiResponseLoading=true;
    });
    
    var apiUrl=Uri.parse("https://api.api-ninjas.com/v1/bucketlist");
    var header={
      "X-Api-key":"2biBAI5tNHZAWHF0Dc0lMQ==kwd1sg5mdqh94szF"
      
    };
    final response=await http.get(apiUrl,headers: header);

    //setState(() {
     // isApiResponseLoading=false;
    //});
    if(response.statusCode==200){
      //print(response.body);
      setState(() {
        
        final json=jsonDecode(response.body);
        RandomBucketList=json["item"];
         isApiResponseLoading=false;
      });
     

      
    }
    else{
       print("Something Went Wrong");
    }


  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text("Api Example")
      ),
      body:Column(
        mainAxisAlignment:MainAxisAlignment.center,
        children: [
          Row(),
          SizedBox(
            height: 30,
          ),
          isApiResponseLoading==true ?
          CircularProgressIndicator():
          Text(
            '"' "$RandomBucketList" '"',
style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,fontStyle: FontStyle.italic),
            ),
          ElevatedButton(onPressed: (){
            fetchRandumBucketList();
          }, child: Text("Click")),
        ],
      )
    );
  }
}